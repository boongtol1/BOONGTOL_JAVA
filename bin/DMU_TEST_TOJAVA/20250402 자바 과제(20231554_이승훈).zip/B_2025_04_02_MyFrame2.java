package DMU_TEST_TOJAVA;

import javax.swing.JFrame;

public class B_2025_04_02_MyFrame2 extends JFrame{

    B_2025_04_02_MyFrame2() {
        this.setTitle("나의 첫GUI");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setSize(300,200);
        this.setVisible(true);

    }
    public static void main(String[] args) {
        B_2025_04_02_MyFrame2 frame = new B_2025_04_02_MyFrame2();
    }
}
