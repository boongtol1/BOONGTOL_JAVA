package DMU_TEST_TOJAVA;

import javax.swing.JFrame;

public class B_2025_04_02_MyFrameEx1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("나의 첫GUI 프로그래밍");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,200);
        frame.setVisible(true);
        
    }
}

// 모든 java gui 프로그램의 시작구조와 같은 역할!(위 코드는)    