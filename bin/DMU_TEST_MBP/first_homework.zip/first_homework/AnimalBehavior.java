package first_homework;

public interface AnimalBehavior {
    // 동물이 내는 소리를 출력
    void makeSound();

    // 동물이 이동하는 방식을 출력
    void move();
}

