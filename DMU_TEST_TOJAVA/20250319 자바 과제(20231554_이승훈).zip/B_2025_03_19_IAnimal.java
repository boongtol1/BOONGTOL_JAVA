package DMU_TEST;

public interface B_2025_03_19_IAnimal {
	void eat();
	

	
	

}
