package DMU_TEST;

public interface P2_PrintInterface {
	void print();

}
